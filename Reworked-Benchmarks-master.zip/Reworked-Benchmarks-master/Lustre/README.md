## Content

Set of Lustre benchmarks

* single_prop : Lustre benchmarks with single property
* multi_prop : Lustre benchmarks with multiple properties
* language_test : Lustre benchmarks to test different language construct

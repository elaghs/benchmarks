## Content
Lustre benchmarks with single property. 

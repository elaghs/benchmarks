Sources for benchmarks:

durationThm*: based on problems by Bertrand Jeannet (courtesy Anders Franzen)

switch*: based on problems from
  N. Halbwachs, P Raymond "A Tutorial of Lustre", 2002

ticket3i*: based on problems by David Merchant* (courtesy Anders Franzen)

traffic*: based on problems by Koen Classen (courtesy Anders Franzen)

_6counter*, ex*, stalmark*, twisted_counters.lus, two_counters*: based on 
  problems by George Hagen


Please note that many of these benchmarks contain deliberately introduced
modifications to alter their behaviors, and do not necessarily reflect the
original creator's design intentions.

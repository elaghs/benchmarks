Sources for benchmarks:

peterson*, readwrite.lus, rtp*, swimmingpool*: based on problems by David 
  Merchant (courtsey of Anders Franzen)


Please note that many of these benchmarks contain deliberately introduced
modifications to alter their behaviors, and do not necessarily reflect the
original creator's design intentions.
